package com.eg.utils;

/**
 * UtilsConstants
 */

public class UtilsConstants {
    public final static String ASSETS_ROOT = "file:///android_asset/";

}
